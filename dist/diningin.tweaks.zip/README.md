# diningin-tweaks
Fix up Diningin with a few tweaks. 

# Install
Install on Chrome Webstore:
https://chrome.google.com/webstore/detail/diningin-enhancments/lkiekaajnilpmkppiglncmgnkjcfpmpj
